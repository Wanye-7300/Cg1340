package cg1340.moreitems.swift_bow;

import net.minecraft.item.BowItem;

public class SwiftBowItem extends BowItem {
    public SwiftBowItem(Settings settings) {
        super(settings);
    }

    @Override
    public int getRange() {
        return 100;
    }
}
