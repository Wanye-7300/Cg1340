package cg1340.moreitems.swift_bow;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;

public class SwiftBowMaterial implements ToolMaterial {

    public static final SwiftBowMaterial INSTANCE = new SwiftBowMaterial();
    public static SwiftBowItem SWIFT_BOW = new SwiftBowItem(new Item.Settings());

    @Override
    public int getDurability() {
        return 1000;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return 3.0F;
    }

    @Override
    public float getAttackDamage() {
        return 10.0F;
    }

    @Override
    public int getMiningLevel() {
        return 3;
    }

    @Override
    public int getEnchantability() {
        return 25;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(Items.ARROW);
    }
}