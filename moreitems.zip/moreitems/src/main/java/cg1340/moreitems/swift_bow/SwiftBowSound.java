package cg1340.moreitems.swift_bow;

import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class SwiftBowSound {
    public static final Identifier SWIFT_BOW_SOUND_ID = new Identifier("moreitems", "swift_bow_sound");
    public static SoundEvent SWIFT_BOW_SOUND_EVENT = SoundEvent.of(SWIFT_BOW_SOUND_ID);
}
