package cg1340.moreitems.copper;

import net.minecraft.item.HoeItem;
import net.minecraft.item.ToolMaterial;

public class CopperHoeItem extends HoeItem {
    public CopperHoeItem(ToolMaterial material, int attackDamage, float attackSpeed, Settings settings) {
        super(material, attackDamage, attackSpeed, settings);
    }
}
