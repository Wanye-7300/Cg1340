package cg1340.moreitems.copper;

import net.minecraft.item.AxeItem;
import net.minecraft.item.ToolMaterial;

public class CopperAxeItem extends AxeItem {
    public CopperAxeItem(ToolMaterial material, float attackDamage, float attackSpeed, Settings settings) {
        super(material, attackDamage, attackSpeed, settings);
    }
}
