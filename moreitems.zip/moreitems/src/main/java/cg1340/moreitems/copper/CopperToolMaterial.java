package cg1340.moreitems.copper;

import net.minecraft.item.*;
import net.minecraft.recipe.Ingredient;

public class CopperToolMaterial implements ToolMaterial {

    public static final CopperToolMaterial INSTANCE = new CopperToolMaterial();
    public static ToolItem COPPER_SHOVEL = new ShovelItem(INSTANCE, 1.5F, -3.0F, new Item.Settings());
    public static ToolItem COPPER_SWORD = new SwordItem(INSTANCE, 3, -2.4F, new Item.Settings());
    public static ToolItem COPPER_PICKAXE = new CopperPickaxeItem(INSTANCE, 1, -2.8F, new Item.Settings());
    public static ToolItem COPPER_AXE = new CopperAxeItem(INSTANCE, 7.0F, -3.2F, new Item.Settings());
    public static ToolItem COPPER_HOE = new CopperHoeItem(INSTANCE, 7, -3.2F, new Item.Settings());

    @Override
    public int getDurability() {
        return 350;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return 6.5F;
    }

    @Override
    public float getAttackDamage() {
        return 2.5F;
    }

    @Override
    public int getMiningLevel() {
        return 2;
    }

    @Override
    public int getEnchantability() {
        return 13;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.ofItems(Items.COPPER_INGOT);
    }
}
