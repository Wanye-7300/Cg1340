package cg1340.moreitems;

import cg1340.moreitems.copper.CopperToolMaterial;
import cg1340.moreitems.swift_bow.SwiftBowMaterial;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class Moreitems implements ModInitializer {

    public static final ItemGroup MOREITEMS_GROUP = FabricItemGroup.builder(new Identifier("moreitems", "moreitems_group"))
            .icon(() -> new ItemStack(Items.COPPER_INGOT))
            .build();

    /**
     * Runs the mod initializer.
     */
    @Override
    public void onInitialize() {
        Registry.register(Registries.ITEM, new Identifier("moreitems", "copper_sword"), CopperToolMaterial.COPPER_SWORD);
        Registry.register(Registries.ITEM, new Identifier("moreitems", "copper_hoe"), CopperToolMaterial.COPPER_HOE);
        Registry.register(Registries.ITEM, new Identifier("moreitems", "copper_shovel"), CopperToolMaterial.COPPER_SHOVEL);
        Registry.register(Registries.ITEM, new Identifier("moreitems", "copper_pickaxe"), CopperToolMaterial.COPPER_PICKAXE);
        Registry.register(Registries.ITEM, new Identifier("moreitems", "copper_axe"), CopperToolMaterial.COPPER_AXE);
        Registry.register(Registries.ITEM, new Identifier("moreitems", "swift_bow"), SwiftBowMaterial.SWIFT_BOW);

        ItemGroupEvents.modifyEntriesEvent(MOREITEMS_GROUP).register(content -> {
            content.add(CopperToolMaterial.COPPER_SWORD);
            content.add(CopperToolMaterial.COPPER_HOE);
            content.add(CopperToolMaterial.COPPER_SHOVEL);
            content.add(CopperToolMaterial.COPPER_PICKAXE);
            content.add(CopperToolMaterial.COPPER_AXE);
            content.add(SwiftBowMaterial.SWIFT_BOW);
        });
    }
}
